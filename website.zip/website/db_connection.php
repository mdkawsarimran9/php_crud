<?php
// database connection 
$serverName = "localhost";
$userName   = "root";
$password   = "";
$dbName     = "mynews";
// connection query 
$conn = new mysqli($serverName, $userName, $password, $dbName);
?>